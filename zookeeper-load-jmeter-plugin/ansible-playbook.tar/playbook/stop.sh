#!/bin/sh
kill $(pidof java)
