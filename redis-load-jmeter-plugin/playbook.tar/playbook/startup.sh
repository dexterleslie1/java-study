#!/bin/sh
nohup sh jmeter-server > nohup.out 2>&1 & echo $! > pid.file
